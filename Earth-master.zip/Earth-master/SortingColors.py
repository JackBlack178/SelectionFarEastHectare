from Get_color_ByPixel import Get_Colors
from height import Estimate_Height
import requests
import json
from PIL import Image,ImageOps
#Green = (
#   [40,60,50],
#)

#Mountain = (
 #   [130,126,62]
#)

Green = 150
Mountain = 390
water = 80
field = 250

urlApi = r'C:\Users\Pascal\Desktop\Earth-master\Api_password'

'подключение апи ключа'
ApiFile = open(urlApi)
ApiPassword = ApiFile.read()
ApiFile.close()

def GetPhoto(longitude, latitude):
    img = requests.post(
        f'https://maps.googleapis.com/maps/api/staticmap?center={longitude},{latitude}&zoom=10&size=200x400&maptype=satellite&format=jpg&key={ApiPassword}').content

    image = open("img.jpg", "wb")
    image.write(img)
    image.close()
    img = Image.open('img.jpg')
    area = (0, 0, 200,200)
    cropped_img = img.crop(area)
    cropped_img.save('img.png', 'png')



    return True






def Get_Relief(latitude,longitude):

    GetPhoto(latitude,longitude)
    photo = Get_Colors('img.png')
    green = 0
    mount = 0
    wat = 0
    field_ = 0
    #if Estimate_Height(latitude,longitude) == False :
     #   return 2
    for i in photo:
        meaning = i[0]+i[1]+i[2]
        if abs(meaning - Green) < abs(meaning - Mountain) and abs(meaning - Green) < abs(meaning - water) and abs(meaning-Green) < abs(meaning-field):
            green+=1
        elif abs(meaning - Mountain) > abs(meaning - water) and abs(meaning-water) < abs(meaning - field):
            wat +=1

        elif abs(meaning-field) < abs(meaning-Mountain):
            field_ +=1

        else:
            mount+=1

    if (field+green)/(green+wat+mount+field) < 0.85:
        4
    if field/(field+green) > 0.80:
        return 0
    return 1












