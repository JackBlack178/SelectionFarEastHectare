from PIL import Image
import colorsys
'''
    Programm which gets images and return color data.
    name_photo - it's path to file,absolute or current directory
    obj it's pixel location (x,y)
    return tuple with 4 data
    return 

I want to increase my accuracy .I'm going to take result from 4 points.
        Programm takes 4 places and gets result there.
        I take photo ~110px*110px ( zoom = 10)
        It's roughly 1 hectare.
        i am getting color data at the corners of hectare
        Return them in list names colors
        
'''
def Get_Col(name_photo):
    #My coordinates are here
    Pixel_place = (
        [1, 1],



    )

    img = Image.open(name_photo)
    obj = img.load()
    colors = [] #creating list for colors

    for coordinates in Pixel_place:
        colors.append(obj[coordinates[0], coordinates[1]])
    return colors    #Return my colors .Format = rgb


print(Get_Col('img.png'))







