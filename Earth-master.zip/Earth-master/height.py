import requests
import json,sys

lgt = 65.036008
lat = 117.870470
def Get_Height(latitude,longitude):
    try:
        a = requests.post('https://maps.googleapis.com/maps/api/elevation/json?locations={},{}&key=AIzaSyCXuqOfQV1kh0VEr37HLj-U6g_ZLoi48Yo'.format(latitude,longitude)).text
        a = json.loads(a)
        return a['results'][0]['elevation']
    except Exception:
        return "Something go wrong",sys.exc_info()




def Estimate_Height(x,y):

    h1 = Get_Height(x+0.025,y+0.025)

    h2 = Get_Height(x+0.025,y-0.025)

    h3 = Get_Height(x-0.025,y-0.025)

    h4 = Get_Height(x-0.025,y+0.025)


    try:
        if abs(h1-h2) >30 or abs(h2-h3)>30 or abs(h3-h4)>30or abs(h1-h4)>30 or h1<0 or h2<0 or h3<0 or h4<0:
            return False
        else:
            return True
    except:
        return True

