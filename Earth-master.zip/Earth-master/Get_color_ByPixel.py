from PIL import Image
from collections import defaultdict
from colorsys import rgb_to_hls

#def colors_hsv(r,g,b):
#    return rgb_to_hls(r,g,b)




def Get_Colors(photo):
    i = 0
    image = Image.open(photo)
    by_color = defaultdict(int)
    for pixel in image.getdata():
        by_color[pixel] += 1



    #for r,g,b in by_color:
     #   r,g,b = colors_hsv(r,g,b)

    return ({k: v for k, v in sorted(dict(by_color).items(), key=lambda item: item[1])})




if __name__ == '__main__':

     print(Get_Colors('img.jpg'))

