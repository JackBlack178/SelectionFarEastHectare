from django.shortcuts import render,reverse,resolve_url,redirect
from django.http import request,JsonResponse
from django.http import HttpResponse, HttpResponseRedirect
import sys
sys.path.insert(1, r'C:\Users\Pascal\Desktop\Earth-master')
import Data_Analysis
from .models import analysisResult






def mainpage(request):
    

    return render(request,'index.html')





def maps(request):

    if request.method == 'POST':
        print('IT\'s post request')
        if request.is_ajax():
            print('IT\'s ajax post request')
            myCoordinate = request.POST.get('coordinate').split()
            print(myCoordinate)
            myCoordinate_lng = float(myCoordinate[0].replace('(','').replace(',',''))
            myCoordinate_lat = float(myCoordinate[1].replace(')',''))


    else:
         return render(request, 'maps.html')



def answer(request,latitude,longitude):
    response = Data_Analysis.Get_Answer(float(latitude),float(longitude))

    return render(request,'result.html',{'form':response})



