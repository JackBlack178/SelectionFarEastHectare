'''Для оценки темперетур в этом модуле мы определим функцию ,которая будет брать пригодные,критические значения
    для температуры ,а также значения влажности.Мы будем подсчитывать вероятность успеха опираясь на данные бд.
    Если температура выходит за критические,то нельзя выращивать.Если не выходит ,то считаем вероятность успеха.
    Температуру переводим в кельвины .Пусть P - вероятность успеха. P = |T1/T2 - 1|*100% + |H1/H2-1|*100%
    Если P < 50 % ,то мы будем выводить ,что не желательно выращивания данного типа растительности на этой территории.
    В противном случае будем выводить вероятность успеха.
'''

'''Определяем функцию.
    Когда пользователь выбирает координаты ,я выбираю близжайшую станцию и говорю ее данные
    
'''
import psycopg2
import re,math
from SortingColors import Get_Relief
from Get_color_ByPixel import Get_Colors
from height import Estimate_Height


def Get_Coord(degrees, minutes, seconds = 0, direction = 'W'):
    lng = float(degrees) + float(minutes)/60 + float(seconds)/(60*60)
    if direction == 'E' or direction == 'N':
        lng *= -1
    return lng

'''Подключение паролz для базы данных '''


urlDb = r'C:\Users\Pascal\Desktop\Earth-master\passwordDb'
DbFile = open(urlDb)
DbPassword = DbFile.read()
DbFile.close()


'''
Сверху блок для перевода координат в градусах в десятичные
Пример ввода
Get_lat("78°55'44.33324'N" )
Get_lng(75,25,0)
'''


#Подключение базы данных


conn = psycopg2.connect(dbname='postgres', user='postgres',
                        password=DbPassword, host='localhost')
cursor = conn.cursor()
cursor.execute('SELECT * FROM stations')
Station = cursor.fetchall()
cursor.close()





def Kelvin(Temperature):
    return Temperature + 273
def Celsius(Temperature):
    return Temperature - 273






#____________________________________________________________________________________________________________________





 # Distance  Для нахождения близжайшей станции

def Distance(longitude,latitude,Station):
    dist_X = longitude - Get_Coord(int(Station[1].split('°')[0]),int(Station[1].split('°')[1][:2]))
    dist_Y = latitude - Get_Coord(int(Station[2].split('°')[0]), int(Station[2].split('°')[1][:2]))

    return math.sqrt(dist_X**2+dist_Y**2)



def WhichStation(longitude,latitude,Stations):
    dist = Distance(longitude,latitude,Stations[0])
    id = Station[0][0]
    for STATION in Stations:
        if dist > Distance(longitude,latitude,STATION):
            dist = Distance(longitude,latitude,STATION)
            id = STATION[0]
    return id
#Test print(WhichStation(69,43))
#______________________________________________________________________________________________________________________
# Мая Июнь Июлю Август Сентябрь



#_________Влажность и температуры получены выше по id________________________________________________________________________________________________________
















#___________________________________________________________________________________________________________________
# First place is name,second place is good temperature,third one is min temperature,fourth is max , well humidity in the end

cursor = conn.cursor()
cursor.execute('SELECT * FROM plants')
Plants = cursor.fetchall()
cursor.close()


#__________________________________________________________________ Function which get photo

#Relief = 0  поле,трава
#Relief = 1  возможно лес
#Relief = 2  скалы или горы
#Relief = 3  озеро,река,море
#Relief = 4  болото


def Estimating(Plants,x,y):
    id = WhichStation(x,y,Station)
    #Получить список температур и влажности по id


    Average_Temperature = 0
    Average_Humidity = 0


    Relief = Get_Relief(x,y)

    if Relief == 2 or Relief == 3 or Relief ==4 :
        return ('No',0)

    cursor = conn.cursor()
    cursor.execute('SELECT * FROM temperature where id = {}'.format(id))
    Temperature = cursor.fetchall()
    cursor.execute('SELECT * FROM humidity where id = {}'.format(id))
    Humidity = cursor.fetchall()
    cursor.close()

    list_plant = []

    for temperatures in Temperature:
        for j in range(1,6):
            if abs(Kelvin(float(Plants[1]))/Kelvin(float(temperatures[j].split(',')[0])) -1) > 0.05:
                return ('No',0)
            Average_Temperature += float(temperatures[j].split(',')[0])

    Average_Temperature /= (len(Temperature)*5)
    for humid in Humidity:
        for j in range(1, 6):
            if abs(float(Plants[-1].replace('%', '')) - float(humid[j].replace('%', ''))) > 25:
                return ('No',0)
            Average_Humidity += float(humid[2])
    Average_Humidity /= (len(Humidity)*5)
    Probability_of_Success = int(100 -abs(Kelvin(float(Plants[2]))/Kelvin(Average_Temperature)-1)*100 - abs(float(Plants[-1].replace('%',''))/Average_Humidity-1)*100)

    if Relief ==1:
        return ('Yes',Probability_of_Success)

    if Relief ==0:
        return ('Yes',Probability_of_Success)




def Response(Plants,latitude,longitude):

    return Estimating(Plants,latitude,longitude)

def Get_Answer(latitude,longitude):
    response = []
    i = 1
    for each in Plants:
        Answer,Probability = Response(each,latitude,longitude)
        response.append((i,each[0],Answer,Probability))
        i+=1
    return response



# Response(each,latitude,longitude) - return answer








#______________________________________________________________________________________________________________




